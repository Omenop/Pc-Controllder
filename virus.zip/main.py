import time
import os
import requests
import threading

# API Endpoints
NEXTJS_CONTROL_API_URL = "https://pc-controllder.vercel.app/api/control"
NEXTJS_POPUP_API_URL = "https://pc-controllder.vercel.app/api/popupText"

# Cooldown Settings
COOLDOWN = 10  
last_executed_command = None
last_executed_time = 0

def execute_command(action):
    """Executes shutdown, restart, or sleep commands silently."""
    if action == "shutdown":
        os.system("shutdown /s /t 0") 
    elif action == "restart":
        os.system("shutdown /r /t 0")  
    elif action == "sleep":
        try:
            os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        except Exception as e:
            print(f"Error entering sleep mode: {e}")
            return False
    else:
        return False
    return True

def poll_control():
    """Polls the Next.js control API and executes commands if available."""
    global last_executed_command, last_executed_time
    print("PC Control Program Running...")
    while True:
        try:
            response = requests.get(NEXTJS_CONTROL_API_URL)
            data = response.json()

            if data.get("success") and "action" in data:
                action = data["action"]
                current_time = time.time()
                if action == last_executed_command and (current_time - last_executed_time < COOLDOWN):
                    print(f"Skipping {action}: executed recently.")
                else:
                    print(f"Executing: {action}")
                    if execute_command(action):
                        last_executed_command = action
                        last_executed_time = current_time
                    else:
                        print(f"Failed to execute {action}")
        except Exception as e:
            print(f"Error fetching control command: {e}")
        
        time.sleep(5)  # Poll every 5 seconds

def execute_popup(message):
    """Opens Notepad with the message."""
    try:
        file_path = os.path.join(os.getenv("TEMP"), "popup_message.txt")
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(message)
        
        os.system(f'notepad "{file_path}"')  # Open Notepad with the file
    except Exception as e:
        print(f"Error opening Notepad: {e}")

def poll_popup():
    """Polls the Next.js popup API and opens Notepad if a message is received."""
    print("PC Popup Poller Running...")
    while True:
        try:
            response = requests.get(NEXTJS_POPUP_API_URL)
            data = response.json()
            if data.get("success") and "message" in data:
                message = data["message"]
                print(f"Opening Notepad with message: {message}")
                execute_popup(message)
        except Exception as e:
            print(f"Error fetching popup command: {e}")
        
        time.sleep(5)

def main():
    popup_thread = threading.Thread(target=poll_popup, daemon=True)
    popup_thread.start()

    poll_control()

if __name__ == "__main__":
    main()
